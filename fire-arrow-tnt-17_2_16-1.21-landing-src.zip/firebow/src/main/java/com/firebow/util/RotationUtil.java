package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * RotationUtil v13 — silent rotation kiểu BOOST-FPS, port sang 1.21 yarn.
 *
 * Trạng thái:
 *   arm()            : HEAD tickMovement, tính góc silent tới điểm đặt, snap lưới chuột.
 *   applyToPacket()  : HEAD sendMovementPackets, đưa silent yaw/pitch lên player để packet mang nó.
 *   end()            : END_CLIENT_TICK, trả yaw/pitch thật.
 *
 * Trong lúc active:
 *   - velocity tính theo silentYaw (EntityMixin), không phụ thuộc player.getYaw() lúc đó.
 *   - input được xoay Δ = realYaw − silentYaw rồi làm tròn (KeyboardInputMixin),
 *     để hướng đi theo phím vẫn khớp camera thật.
 *
 * Chỉ dùng trên main thread.
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static boolean active      = false;
    private static float   realYaw     = 0f;
    private static float   realPitch   = 0f;
    private static float   silentYaw   = 0f;
    private static float   silentPitch = 0f;

    public static boolean isActive()  { return active; }
    public static float   realYaw()   { return realYaw; }
    public static float   silentYaw() { return silentYaw; }

    public static void arm(ClientPlayerEntity player, Vec3d hitVec) {
        if (active || player == null) return;
        realYaw   = player.getYaw();
        realPitch = player.getPitch();
        float[] rot = snapToMouseGrid(player, calcRotationFromEye(player.getEyePos(), hitVec));
        silentYaw   = rot[0];
        silentPitch = rot[1];
        active = true;
    }

    /** HEAD sendMovementPackets. */
    public static void applyToPacket(ClientPlayerEntity player) {
        if (!active || player == null) return;
        applyRaw(player, silentYaw, silentPitch);
    }

    /** END_CLIENT_TICK. An toàn khi gọi khi không active. */
    public static void end(ClientPlayerEntity player) {
        if (active && player != null) applyRaw(player, realYaw, realPitch);
        active = false;
    }

    // ─── Mouse grid (AimModulo360) ───────────────────────────────────────────

    /** Bước góc nhỏ nhất chuột vanilla tạo ra ở sensitivity hiện tại. */
    public static double mouseStep() {
        double sens = MinecraftClient.getInstance().options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        return f * f * f * 8.0 * 0.15;
    }

    /** Snap góc đích về lưới chuột, delta tính từ góc hiện tại của player. */
    public static float[] snapToMouseGrid(ClientPlayerEntity player, float[] rot) {
        double step   = mouseStep();
        double curYaw = player.getYaw();
        double curPit = player.getPitch();

        double dYaw   = wrap180(rot[0] - curYaw);
        double dPitch = rot[1] - curPit;

        double yaw   = curYaw + Math.round(dYaw   / step) * step;
        double pitch = curPit + Math.round(dPitch / step) * step;

        double maxPitch = Math.floor(90.0 / step) * step;
        pitch = Math.max(-maxPitch, Math.min(maxPitch, pitch));

        return new float[]{ (float) yaw, (float) pitch };
    }

    private static double wrap180(double deg) {
        return ((deg % 360.0) + 540.0) % 360.0 - 180.0;
    }

    // ─── Math ────────────────────────────────────────────────────────────────

    /** Công thức giống Entity.updateVelocity của vanilla, nhưng dùng yaw truyền vào. */
    public static Vec3d movementInputToVelocity(Vec3d input, float speed, float yaw) {
        double d = input.lengthSquared();
        if (d < 1.0E-7) return Vec3d.ZERO;
        Vec3d v = (d > 1.0 ? input.normalize() : input).multiply(speed);
        double rad = Math.toRadians(yaw);
        double s = Math.sin(rad);
        double c = Math.cos(rad);
        return new Vec3d(v.x * c - v.z * s, v.y, v.z * c + v.x * s);
    }

    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    private static void applyRaw(ClientPlayerEntity player, float yaw, float pitch) {
        player.setYaw(yaw);
        player.setPitch(pitch);
        player.headYaw = yaw;
        player.bodyYaw = yaw;
    }
}
